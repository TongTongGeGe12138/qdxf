const s="/assets/dark-R4tNeb17.svg";export{s as _};
